export const brand = {
  name: "Beez Pixel",
  phoneIntl: "40757830584",
  website: "beezpixel.ro"
};